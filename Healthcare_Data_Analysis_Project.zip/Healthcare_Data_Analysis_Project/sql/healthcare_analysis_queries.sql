-- Healthcare Patient Analytics Project
-- Synthetic dataset; safe for portfolio use.

CREATE DATABASE IF NOT EXISTS healthcare_analytics;
USE healthcare_analytics;

CREATE TABLE patient_data (
    Patient_ID VARCHAR(10) PRIMARY KEY,
    Age INT,
    Gender VARCHAR(10),
    Department VARCHAR(50),
    Doctor VARCHAR(100),
    Diagnosis VARCHAR(100),
    Admission_Date DATE,
    Length_of_Stay_Days INT,
    Treatment_Cost_INR DECIMAL(12,2),
    Insurance_Type VARCHAR(30),
    Satisfaction_Score INT,
    Outcome VARCHAR(50),
    Readmission_30_Days VARCHAR(5)
);

-- After importing healthcare_patient_data.csv, the following analysis queries can be used.

-- 1. Total patients
SELECT COUNT(*) AS total_patients
FROM patient_data;

-- 2. Total and average treatment cost
SELECT 
    SUM(Treatment_Cost_INR) AS total_treatment_cost,
    AVG(Treatment_Cost_INR) AS avg_treatment_cost
FROM patient_data;

-- 3. Patients by department
SELECT Department, COUNT(*) AS patient_count
FROM patient_data
GROUP BY Department
ORDER BY patient_count DESC;

-- 4. Average length of stay by department
SELECT Department, ROUND(AVG(Length_of_Stay_Days), 2) AS avg_stay_days
FROM patient_data
GROUP BY Department
ORDER BY avg_stay_days DESC;

-- 5. Monthly admissions
SELECT DATE_FORMAT(Admission_Date, '%Y-%m') AS month,
       COUNT(*) AS admissions
FROM patient_data
GROUP BY DATE_FORMAT(Admission_Date, '%Y-%m')
ORDER BY month;

-- 6. Revenue by insurance type
SELECT Insurance_Type,
       COUNT(*) AS patients,
       SUM(Treatment_Cost_INR) AS total_cost,
       ROUND(AVG(Treatment_Cost_INR), 2) AS avg_cost
FROM patient_data
GROUP BY Insurance_Type
ORDER BY total_cost DESC;

-- 7. Top 5 doctors by patient volume
SELECT Doctor, COUNT(*) AS patient_count
FROM patient_data
GROUP BY Doctor
ORDER BY patient_count DESC
LIMIT 5;

-- 8. Satisfaction by department
SELECT Department,
       ROUND(AVG(Satisfaction_Score),2) AS avg_satisfaction
FROM patient_data
GROUP BY Department
ORDER BY avg_satisfaction DESC;

-- 9. Readmission rate
SELECT 
    ROUND(100.0 * SUM(CASE WHEN Readmission_30_Days='Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS readmission_rate_pct
FROM patient_data;

-- 10. High-cost patients
SELECT *
FROM patient_data
WHERE Treatment_Cost_INR >= 75000
ORDER BY Treatment_Cost_INR DESC;

-- 11. Department-wise outcome distribution
SELECT Department, Outcome, COUNT(*) AS patients
FROM patient_data
GROUP BY Department, Outcome
ORDER BY Department, patients DESC;

-- 12. Monthly treatment cost
SELECT DATE_FORMAT(Admission_Date, '%Y-%m') AS month,
       SUM(Treatment_Cost_INR) AS total_cost
FROM patient_data
GROUP BY DATE_FORMAT(Admission_Date, '%Y-%m')
ORDER BY month;

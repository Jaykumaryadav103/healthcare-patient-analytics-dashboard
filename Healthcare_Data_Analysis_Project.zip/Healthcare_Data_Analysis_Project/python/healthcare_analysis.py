"""
Healthcare Patient Analytics
Run:
    python healthcare_analysis.py

Input:
    ../data/healthcare_patient_data.csv

Outputs:
    charts/*.png
    analysis_summary.csv
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data" / "healthcare_patient_data.csv"
CHARTS = BASE / "python" / "charts"
CHARTS.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["Admission_Date"])

# Basic checks
print("Rows:", len(df))
print("Columns:", len(df.columns))
print("\nMissing values:\n", df.isna().sum())

# KPIs
total_patients = len(df)
total_cost = df["Treatment_Cost_INR"].sum()
avg_cost = df["Treatment_Cost_INR"].mean()
avg_stay = df["Length_of_Stay_Days"].mean()
avg_satisfaction = df["Satisfaction_Score"].mean()
readmission_rate = (df["Readmission_30_Days"].eq("Yes").mean()) * 100

summary = pd.DataFrame({
    "Metric": [
        "Total Patients", "Total Treatment Cost (INR)", "Average Treatment Cost (INR)",
        "Average Length of Stay (Days)", "Average Satisfaction", "30-Day Readmission Rate (%)"
    ],
    "Value": [
        total_patients, round(total_cost,2), round(avg_cost,2),
        round(avg_stay,2), round(avg_satisfaction,2), round(readmission_rate,2)
    ]
})
summary.to_csv(BASE / "python" / "analysis_summary.csv", index=False)

# Department summary
dept = df.groupby("Department").agg(
    Patients=("Patient_ID","count"),
    Total_Cost=("Treatment_Cost_INR","sum"),
    Avg_Cost=("Treatment_Cost_INR","mean"),
    Avg_Stay=("Length_of_Stay_Days","mean"),
    Avg_Satisfaction=("Satisfaction_Score","mean")
).reset_index()
dept.to_csv(BASE / "python" / "department_summary.csv", index=False)

# Monthly summary
df["Month"] = df["Admission_Date"].dt.to_period("M").astype(str)
monthly = df.groupby("Month").agg(
    Admissions=("Patient_ID","count"),
    Total_Cost=("Treatment_Cost_INR","sum")
).reset_index()
monthly.to_csv(BASE / "python" / "monthly_summary.csv", index=False)

# Chart 1: admissions by department
ax = dept.sort_values("Patients", ascending=False).plot(
    x="Department", y="Patients", kind="bar", legend=False, figsize=(9,5),
    title="Patients by Department"
)
ax.set_xlabel("Department")
ax.set_ylabel("Patient Count")
plt.tight_layout()
plt.savefig(CHARTS / "patients_by_department.png", dpi=150)
plt.close()

# Chart 2: monthly admissions
ax = monthly.plot(x="Month", y="Admissions", kind="line", marker="o", legend=False, figsize=(10,5),
                  title="Monthly Admissions Trend")
ax.set_xlabel("Month")
ax.set_ylabel("Admissions")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(CHARTS / "monthly_admissions.png", dpi=150)
plt.close()

# Chart 3: cost by department
ax = dept.sort_values("Total_Cost", ascending=False).plot(
    x="Department", y="Total_Cost", kind="bar", legend=False, figsize=(9,5),
    title="Treatment Cost by Department"
)
ax.set_xlabel("Department")
ax.set_ylabel("Treatment Cost (INR)")
plt.tight_layout()
plt.savefig(CHARTS / "cost_by_department.png", dpi=150)
plt.close()

# Chart 4: satisfaction by department
ax = dept.sort_values("Avg_Satisfaction", ascending=False).plot(
    x="Department", y="Avg_Satisfaction", kind="bar", legend=False, figsize=(9,5),
    title="Average Satisfaction by Department"
)
ax.set_xlabel("Department")
ax.set_ylabel("Average Satisfaction")
ax.set_ylim(0,5)
plt.tight_layout()
plt.savefig(CHARTS / "satisfaction_by_department.png", dpi=150)
plt.close()

print("\nAnalysis complete. Check python/charts/")

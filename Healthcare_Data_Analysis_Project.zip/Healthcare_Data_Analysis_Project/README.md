# Healthcare Patient Analytics & Hospital Performance Dashboard

A beginner-to-intermediate Data Analyst portfolio project focused on **reporting, Excel, SQL, and Python analysis** using a fully synthetic healthcare dataset.

## Project Headline
**Healthcare Patient Analytics | Excel MIS Reporting | SQL Analysis | Python Visualization**

## Business Objective
Create a simple reporting system that helps a hospital understand:
- patient volume
- department performance
- monthly admissions
- treatment cost
- length of stay
- insurance mix
- patient satisfaction
- 30-day readmission

## Tools
- Excel
- SQL / MySQL
- Python
- Pandas
- Matplotlib

## Project Structure
```text
Healthcare_Data_Analysis_Project/
│
├── data/
│   └── healthcare_patient_data.csv
│
├── excel/
│   └── healthcare_reporting_dashboard.xlsx
│
├── sql/
│   └── healthcare_analysis_queries.sql
│
├── python/
│   ├── healthcare_analysis.py
│   ├── requirements.txt
│   ├── analysis_summary.csv
│   ├── department_summary.csv
│   ├── monthly_summary.csv
│   └── charts/
│
├── docs/
│   ├── project_scope.md
│   ├── data_dictionary.md
│   ├── github_upload_steps.md
│   └── interview_questions_and_answers.md
│
└── README.md
```

## Dataset
The dataset contains 1,000 synthetic patient records with:
- Patient ID
- Age
- Gender
- Department
- Doctor
- Diagnosis
- Admission Date
- Length of Stay
- Treatment Cost
- Insurance Type
- Satisfaction Score
- Outcome
- 30-Day Readmission

## Excel Reporting
The Excel workbook contains:
1. **Dashboard** – KPI cards and management charts
2. **Patient_Data** – full dataset
3. **Monthly_Summary** – monthly admissions and cost
4. **Department_Summary** – patient volume, cost, stay, satisfaction
5. **Insurance_Summary** – insurance-wise patient and cost reporting

## SQL Analysis
The SQL file includes practical queries for:
- total patients
- total and average treatment cost
- department performance
- monthly admissions
- insurance analysis
- top doctors
- satisfaction
- readmission rate
- high-cost cases
- outcome distribution

## Python Analysis
Run:
```bash
cd python
pip install -r requirements.txt
python healthcare_analysis.py
```

The script creates CSV summaries and four charts.

## Resume Project Description
**Healthcare Patient Analytics & Hospital Performance Dashboard**
- Analyzed 1,000 synthetic patient records using Excel, SQL, and Python.
- Built MIS-style reports for patient volume, treatment cost, length of stay, insurance mix, satisfaction, and readmission.
- Used SQL aggregation and filtering to create department, monthly, doctor, and insurance reports.
- Used Python/Pandas and Matplotlib to validate trends and create business-ready visualizations.

## Interview Talking Point
I treated the project as a reporting assignment. I started with data quality checks, prepared Excel MIS reports, used SQL to answer business questions, and then used Python to validate the trends and create visual charts.

## Important Note
This project contains **synthetic healthcare data only**. It does not contain real patient records and should not be used for medical decision-making.

## Suggested GitHub Repository Name
`healthcare-patient-analytics-dashboard`

# GitHub Upload Steps

1. Create a new GitHub repository named:
   `healthcare-patient-analytics-dashboard`
2. Keep the repository Public if you want recruiters to view it.
3. Download and extract this project ZIP.
4. Open the extracted project folder.
5. Upload all folders and files to the GitHub repository.
6. Make sure `README.md` is in the root of the repository.
7. Open the repository and confirm that `data`, `excel`, `sql`, `python`, and `docs` are visible.
8. Add the repository link to your resume under Projects.

Recommended GitHub description:
`Healthcare reporting and analytics project using Excel, SQL and Python on a synthetic hospital dataset.`

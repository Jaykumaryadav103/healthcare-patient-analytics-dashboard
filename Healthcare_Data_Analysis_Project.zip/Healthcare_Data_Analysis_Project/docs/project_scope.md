# Project Scope

## Business Questions
1. How many patients were admitted?
2. Which departments handled the highest patient volume?
3. What is the monthly admission trend?
4. Which departments generated the highest treatment cost?
5. What is the average length of stay by department?
6. Which insurance groups contributed the most treatment cost?
7. What is the average patient satisfaction by department?
8. What is the 30-day readmission rate?
9. Which doctors handled the highest number of patients?
10. Which patients/treatments have unusually high costs?

## Workflow
Data Collection → Data Quality Check → Excel Reporting → SQL Analysis → Python Validation & Visualization → Insights → Business Recommendations

## Portfolio Note
This project uses entirely synthetic healthcare data. It is intended for learning and portfolio demonstration only.

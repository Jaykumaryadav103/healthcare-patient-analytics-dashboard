# Data Dictionary

| Column | Meaning |
|---|---|
| Patient_ID | Synthetic unique patient identifier |
| Age | Patient age in years |
| Gender | Patient gender category |
| Department | Hospital department |
| Doctor | Assigned doctor |
| Diagnosis | Recorded diagnosis category |
| Admission_Date | Date of admission |
| Length_of_Stay_Days | Number of inpatient days |
| Treatment_Cost_INR | Synthetic treatment cost in INR |
| Insurance_Type | Insurance/payment category |
| Satisfaction_Score | Patient satisfaction score from 1 to 5 |
| Outcome | Discharge/outcome category |
| Readmission_30_Days | Whether the patient returned within 30 days |

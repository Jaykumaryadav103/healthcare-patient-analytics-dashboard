# Healthcare Data Analysis – Interview Questions & Speakable Answers

## 1. Tell me about your project.
I created a Healthcare Patient Analytics project using a synthetic hospital dataset. I cleaned and analyzed patient admissions, treatment cost, length of stay, department performance, insurance type, patient satisfaction, and readmission rate. I used Excel for reporting, SQL for analysis, and Python for charts and validation.

## 2. What was the main objective?
The main objective was to convert patient-level hospital data into simple management reports and KPIs that can help understand patient volume, cost, department performance, and service quality.

## 3. Which tools did you use?
I used Excel for cleaning and reporting, SQL for querying and aggregation, and Python with Pandas and Matplotlib for analysis and visualization.

## 4. What KPIs did you track?
Total patients, total treatment cost, average treatment cost, average length of stay, average satisfaction score, and 30-day readmission rate.

## 5. How did you handle data quality?
I checked for missing values, duplicate patient IDs, invalid dates, abnormal age values, and inconsistent category values before analysis.

## 6. What did you analyze in SQL?
I used GROUP BY, aggregate functions, CASE statements, date functions, filtering, sorting, and LIMIT to create department, monthly, insurance, doctor, and readmission reports.

## 7. Why did you use a synthetic dataset?
The project is designed for a portfolio, so the patient data is fully synthetic. It avoids using private or identifiable real patient information while still allowing realistic analytics practice.

## 8. How would you explain the dashboard to a manager?
I would start with the KPI cards, then show patient volume by department, monthly admission trend, treatment cost by department, and satisfaction. Finally, I would highlight unusual changes or areas that need further investigation.

## 9. What is one limitation of the project?
The dataset is synthetic and represents one year of data, so the findings should be treated as a demonstration of analytical method rather than real hospital performance.

## 10. What would you improve next?
I would connect the reporting layer to a live database, automate refreshes, add Power BI, and create more detailed drill-down reports for departments and doctors.
